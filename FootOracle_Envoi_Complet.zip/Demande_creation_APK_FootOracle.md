# Demande : compiler et livrer l'APK « Foot Oracle »

## Message à copier-coller
> Bonjour, je voudrais obtenir l'application Android **Foot Oracle** sous forme d'APK installable. Je n'ai pas d'ordinateur. Je vous joins : (1) `FootOracle_Projet_Complet.zip` (projet complet), (2) `FootOracle_Android_Build.yml` (workflow GitHub Actions), (3) ce document. Merci de compiler l'APK (`app-debug.apk` suffit), de me le livrer et de me transmettre le message d'erreur complet si le build échoue. Solutions gratuites uniquement, et merci de ne pas modifier les règles de pronostic sans mon accord.

## Fichiers fournis
1. `FootOracle_Projet_Complet.zip` : dossiers `FootOracle_Android` (application), `python` (moteur de référence), `.github` (workflow).
2. `FootOracle_Android_Build.yml` : workflow qui lance les tests puis compile l'APK. Il accepte le ZIP déposé tel quel à la racine du dépôt GitHub.
3. `Demande_creation_APK_FootOracle.md` : ce document.

## Nature de l'application
- Application **hors ligne** : une WebView affiche une interface HTML/JS embarquée (`app/src/main/assets/www/`). Aucun serveur, **aucune permission Internet**.
- Moteur d'analyse en JavaScript (`engine.js`), portage d'un moteur Python de référence (`python/`).
- Contenu : règles du cahier des charges (logiques 1, 2, 3 avant-match ; règles live), modèle de Poisson (Over 0,5 à 3,5 ; Under 1,5 à 3,5), historique des pronostics, fiabilité, backtest.
- Données saisies à la main en JSON (source : Wanyzbet) ; stockées uniquement sur le téléphone.

## Paramètres techniques
- Gradle 8.9, Android Gradle Plugin 8.7.3, Java 17, compileSdk/targetSdk 35, minSdk 23.
- Identifiant `com.footoracle.app` ; nom affiché « Foot Oracle » ; icône Android par défaut.

## État réel de la qualité (à ne pas surestimer)
- **Testé** : 30 tests Python et 24 tests JavaScript passent (dont des tests de cohérence entre les deux moteurs). L'interface a été exercée avec un faux DOM.
- **Non testé** : la compilation de l'APK et l'exécution sur un vrai téléphone. Le premier build est le premier vrai test.
- **Non vérifié** : toute connexion automatique à Wanyzbet (non prévue : saisie manuelle).
- Les probabilités du modèle de Poisson sont des estimations ; leur fiabilité n'est pas mesurée tant que des résultats réels n'ont pas été enregistrés. Aucun gain n'est garanti.

## Critères de réussite
1. Le build produit `app-debug.apk` sans erreur.
2. L'application s'installe et s'ouvre sur Android 6.0 ou plus récent.
3. « Charger des données FICTIVES (démo) » puis « Analyser » affiche des sélections et des probabilités, sans plantage.
4. L'onglet Historique permet de saisir un score ; l'onglet Fiabilité affiche « confiance non évaluée ».
5. Le bouton Retour ferme l'application sans plantage.

## Règles métier validées par le propriétaire (ne pas modifier sans accord)
- Fenêtre d'analyse au choix : 30 min, 1 h, 2 h (défaut), 3 h, 6 h, 12 h.
- Règles live : de la 18e à la 70e minute ; aucun pronostic live au-delà de la 70e minute (y compris matchs de 2 × 40 min).
- Matchs sans « attaques dangereuses » : ignorés par les règles live (aucune règle de remplacement).
- Logique 3 : seuil « moins de t buts » par équipe ; **méthode par défaut = fourchette de S−1 à S** (S = somme des seuils). Un menu permet aussi le « plafond » (total ≤ (t₁−1)+(t₂−1)) en option.
- Une donnée manquante n'est jamais inventée ni complétée : le match est ignoré.

## Contraintes
- Solutions gratuites ou peu coûteuses uniquement.
- Pas de promesse de gain : les pronostics restent probabilistes.
